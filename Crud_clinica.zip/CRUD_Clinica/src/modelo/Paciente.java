
package modelo;


public class Paciente {
    private String rut;
    private String nombre;
    private String apellido;
    private String sexo;
    private String fechaNacimiento;
    private String previsionSalud;
    private String grupoSanguineo;
    private boolean pacienteActivo;
    private String unidadMedica;
    private boolean defuncion;
    private String evolucion;

    public Paciente() {
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getPrevisionSalud() {
        return previsionSalud;
    }

    public void setPrevisionSalud(String previsionSalud) {
        this.previsionSalud = previsionSalud;
    }

    public String getGrupoSanguineo() {
        return grupoSanguineo;
    }

    public void setGrupoSanguineo(String grupoSanguineo) {
        this.grupoSanguineo = grupoSanguineo;
    }

    public boolean isPacienteActivo() {
        return pacienteActivo;
    }

    public void setPacienteActivo(boolean pacienteActivo) {
        this.pacienteActivo = pacienteActivo;
    }

    public String getUnidadMedica() {
        return unidadMedica;
    }

    public void setUnidadMedica(String unidadMedica) {
        this.unidadMedica = unidadMedica;
    }

    public boolean isDefuncion() {
        return defuncion;
    }

    public void setDefuncion(boolean defuncion) {
        this.defuncion = defuncion;
    }

    public String getEvolucion() {
        return evolucion;
    }

    public void setEvolucion(String evolucion) {
        this.evolucion = evolucion;
    }

    @Override
    public String toString() {
        return "Paciente{" + "rut=" + rut + ", nombre=" + nombre + ", apellido=" + apellido + ", sexo=" + sexo + ", fechaNacimiento=" + fechaNacimiento + ", previsionSalud=" + previsionSalud + ", grupoSanguineo=" + grupoSanguineo + ", pacienteActivo=" + pacienteActivo + ", unidadMedica=" + unidadMedica + ", defuncion=" + defuncion + ", historial=" + evolucion + '}';
    }

   
    


    
}

    