package controlador;

import modelo.Paciente;
import bd.Conexion;
import java.sql.*;
import java.util.ArrayList;

public class RegistroPaciente {

    /*
    El método agregarPaciente() añade un registro a la base de datos
    del paciente ingresado por pantalla
     */
    public boolean agregarPaciente(Paciente paciente) {
        try {
            Connection conexion = Conexion.getConexion();
            String query = "insert into paciente(rut_paciente, nombre,apellido, sexo, fecha_nacimiento, prevision_salud, grupo_sanguineo, paciente_activo,unidad_medica,defuncion) "
                    + "values (?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement ins = conexion.prepareStatement(query);
            //ins.setString(1, producto.getCodigo());

            ins.setString(1, paciente.getRut());
            ins.setString(2, paciente.getNombre());
            ins.setString(3, paciente.getApellido());
            ins.setString(4, String.valueOf(paciente.getSexo()));
            ins.setString(5, paciente.getFechaNacimiento());
            ins.setString(6, paciente.getPrevisionSalud());
            ins.setString(7, paciente.getGrupoSanguineo());
            ins.setBoolean(8, paciente.isPacienteActivo());
            ins.setString(9, paciente.getUnidadMedica());
            ins.setBoolean(10, paciente.isDefuncion());

            if (ins.executeUpdate() > 0) {
                return true;
            }

        } catch (Exception e) {
            System.out.println("Error: No se pudo agregar " + e.getMessage());
        }
        return false;
    }

    public Paciente buscarPorRut(String rut) {
        Paciente paciente = null;
        try {
            Connection conexion = Conexion.getConexion();
            String query = "select * from Paciente WHERE rut_paciente=?";
            PreparedStatement bus = conexion.prepareStatement(query);
            bus.setString(1, rut);
            ResultSet rs = bus.executeQuery();
            while (rs.next()) {
                paciente = new Paciente();
                paciente.setRut(rs.getString("rut_paciente"));
                paciente.setNombre(rs.getString("nombre"));
                paciente.setApellido(rs.getString("apellido"));
                paciente.setSexo(rs.getString("sexo"));
                paciente.setFechaNacimiento(rs.getString("fecha_nacimiento"));
                paciente.setGrupoSanguineo(rs.getString("grupo_sanguineo"));
                paciente.setPacienteActivo(rs.getBoolean("paciente_activo"));
                paciente.setUnidadMedica(rs.getString("unidad_medica"));
                paciente.setDefuncion(rs.getBoolean("defuncion"));
            }
        } catch (Exception e) {
            System.out.println("Error al buscar rut "
                    + e.getMessage());
        }
        return paciente;

    }

    public boolean validarRut(String rut) {
        try {
            Connection conexion = Conexion.getConexion();
            String query = "SELECT * FROM Paciente WHERE rut_paciente=?";
            PreparedStatement bus = conexion.prepareStatement(query);
            bus.setString(1, rut);
            ResultSet rs = bus.executeQuery();
            if (rs.next()) {
                return true;
            }
        } catch (Exception e) {
            System.out.println("Error al validar el rut " + e.getMessage());
        }
        return false;
    }
    

    public boolean darDeAlta(String rut, boolean marcarDefuncion) {
    try {
        Connection conexion = Conexion.getConexion();
        String query;
        
        if (marcarDefuncion) {
            query = "UPDATE Paciente SET paciente_activo = 0, defuncion = 1 WHERE rut_paciente = ?";
        } else {
            query = "UPDATE Paciente SET paciente_activo = 0 WHERE rut_paciente = ?";
        }
        
        PreparedStatement mod = conexion.prepareStatement(query);
        mod.setString(1, rut);
        
        if (mod.executeUpdate() > 0) {
            return true;
        }
    } catch (Exception e) {
        System.out.println("Error al dar de alta al paciente: " + e.getMessage());
    }
    
    return false;
}

    public ArrayList<Paciente> buscarPorParametro(String campo, String valor) {
        ArrayList<Paciente> lista = new ArrayList<>();
        try {
            Connection conexion = Conexion.getConexion();
            String query = "SELECT * FROM Paciente WHERE " + campo + "=?";
            PreparedStatement bus = conexion.prepareStatement(query);
            bus.setString(1, valor);
            ResultSet rs = bus.executeQuery();
            // leemos el ResultSet
            while (rs.next()) {
                Paciente paciente = new Paciente();
                paciente.setRut(rs.getString("rut_paciente"));
                paciente.setNombre(rs.getString("nombre"));
                paciente.setApellido(rs.getString("apellido"));
                paciente.setSexo(rs.getString("sexo"));
                paciente.setFechaNacimiento(rs.getString("fecha_nacimiento"));
                paciente.setGrupoSanguineo(rs.getString("grupo_sanguineo"));
                paciente.setPacienteActivo(rs.getBoolean("paciente_activo"));
                paciente.setUnidadMedica(rs.getString("unidad_medica"));
                paciente.setDefuncion(rs.getBoolean("defuncion"));

                lista.add(paciente);
            }

        } catch (Exception e) {
            System.out.println("Error al buscar por parámetro: " + e.getMessage());
        }
        return lista;
    }

    public boolean eliminarPaciente(String rut) {
        try {
            Connection conexion = Conexion.getConexion();
            String query = "DELETE FROM Paciente WHERE rut_paciente=?";
            PreparedStatement del = conexion.prepareStatement(query);
            del.setString(1, rut);
            if (del.executeUpdate() > 0) {
                return true;
            }
        } catch (Exception e) {
            System.out.println("Error al eliminar " + e.getMessage());

        }
        return false;
    }

    public String obtenerEvolucionPorRut(String rut) {
        String evolucion = "";

        try {
            
            Connection conexion = Conexion.getConexion();

            String query = "SELECT evolucion FROM paciente WHERE rut_paciente = ?";
            PreparedStatement mod = conexion.prepareStatement(query);
            mod.setString(1, rut);

            ResultSet rs = mod.executeQuery();

            if (rs.next()) {
                evolucion = rs.getString("evolucion");
            }
        } catch (Exception e) {
            System.out.println("Error al obtener evolución: " + e.getMessage());
        }

        return evolucion;
    }
    
    public boolean guardarEvolucion(Paciente paciente) {
    boolean exito = false;
    
    try {
        Connection conexion = Conexion.getConexion(); 
        
        // Verificar si el paciente ya existe en la base de datos
        String consultaExistencia = "SELECT COUNT(*) AS contador FROM paciente WHERE rut_paciente = ?";
        PreparedStatement existeRut = conexion.prepareStatement(consultaExistencia);
        existeRut.setString(1, paciente.getRut());
        ResultSet existenciaRs = existeRut.executeQuery();
        existenciaRs.next();
        int count = existenciaRs.getInt("contador");
        
        if (count > 0) {
            String consultaActualizacion = "UPDATE paciente SET evolucion = ? WHERE rut_paciente = ?";
            PreparedStatement mod = conexion.prepareStatement(consultaActualizacion);
            mod.setString(1, paciente.getEvolucion());
            mod.setString(2, paciente.getRut());
            int filasActualizadas = mod.executeUpdate();
            
            if (filasActualizadas > 0) {
                exito = true;
            }
        } else {
            String consultaInsercion = "INSERT INTO tabla_pacientes (rut, evolucion) VALUES (?, ?)";
            PreparedStatement mod2 = conexion.prepareStatement(consultaInsercion);
            mod2.setString(1, paciente.getRut());
            mod2.setString(2, paciente.getEvolucion());
            int filasInsertadas = mod2.executeUpdate();
            
            if (filasInsertadas > 0) {
                exito = true;
            }
        }
        
        conexion.close();
    } catch (Exception e) {
        System.out.println("Error al guardar la evolución del paciente: " + e.getMessage());
    }
    
    return exito;
}

}
