
package controlador;

import modelo.Paciente;
import bd.Conexion;
import java.sql.*;
import java.util.ArrayList;

public class RegistroPaciente {
    
        public boolean agregarPaciente(Paciente paciente) {
        try {
            Connection conexion = Conexion.getConexion();
            String query = "insert into paciente(rut_paciente, nombre,apellido, sexo, fecha_nacimiento, num_telefono, prevision_salud,	grupo_sanguineo, paciente_activo,unidad_medica) "+
                        "values (?,?,?,?,?,?,?,?,?)";
            PreparedStatement ins = conexion.prepareStatement(query);
            //ins.setString(1, producto.getCodigo());
            
            ins.setString(1, paciente.getNombre());
            ins.setString(2, paciente.getApellido());
            ins.setString(3,String.valueOf(paciente.getSexo()));
            ins.setString(4,paciente.getFechaNacimiento());
            ins.setString(5,String.valueOf(paciente.getNumTelefono()));
            ins.setString(6, paciente.getPrevisionSalud());
            ins.setString(7, paciente.getGrupoSanguineo());
            ins.setBoolean(8, paciente.isPacienteActivo());
            ins.setString(9, paciente.getUnidadMedica());

            if (ins.executeUpdate() > 0) {
                return true;
            }

        } catch (Exception e) {
            System.out.println("Error: No se pudo agregar " + e.getMessage());
        }
        return false;
    }
        
        public Paciente buscarPorRut(String rut) {
        Paciente paciente = null;
        try {
            Connection conexion = Conexion.getConexion();
            String query = "select * from Paciente WHERE rut_paciente=?";
            PreparedStatement bus = conexion.prepareStatement(query);
            bus.setString(1, rut);
            ResultSet rs = bus.executeQuery();
            while (rs.next()) {
                paciente = new Paciente();
                paciente.setRut(rs.getString("rut_paciente"));
                paciente.setNombre(rs.getString("nombre"));
                paciente.setApellido(rs.getString("apellido"));
                paciente.setSexo(rs.getString("sexo"));
                paciente.setFechaNacimiento(rs.getString("fecha_nacimiento"));
                paciente.setNumTelefono(rs.getInt("num_telefono"));
                paciente.setGrupoSanguineo(rs.getString("grupo_sanguineo"));
                paciente.setPacienteActivo(rs.getBoolean("paciente_activo"));
                paciente.setUnidadMedica(rs.getString("unidad_medica"));
            }
        } catch (Exception e) {
            System.out.println("Error al buscar por rut "
                    + e.getMessage());
        }
        return paciente;
    }
    
}


